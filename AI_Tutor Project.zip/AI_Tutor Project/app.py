import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import io

# ========== PAGE CONFIG ==========
st.set_page_config(
    page_title="An AI Tutor for Personalized Student Learning Recommendations",
    page_icon="",
    layout="wide"
)

# ========== FUNCTION: Download Recommendations Text ==========
def get_recommendations_text(recommendations, student_id):
    text = """
========================================
An AI Tutor for Personalized student Learning Recommendations
Student ID: """ + str(student_id) + """
========================================

Overall Performance: """ + recommendations['overall'] + """
Average Marks: """ + str(round(recommendations['avg_marks'], 1)) + """%
Average Attendance: """ + str(round(recommendations['avg_attendance'], 1)) + """%

----------------------------------------
Subject-wise Recommendations
----------------------------------------
"""
    for rec in recommendations['subject_recs']:
        text = text + "\n" + rec['subject'] + " (" + str(rec['marks']) + "%): " + rec['recommendation']
    
    if recommendations['weak_subjects']:
        text = text + "\n\nWeak Subjects: " + ', '.join(recommendations['weak_subjects'])
    else:
        text = text + "\n\nNo weak subjects! Keep it up!"
    
    if recommendations['strong_subjects']:
        text = text + "\nStrong Subjects: " + ', '.join(recommendations['strong_subjects'])
    
    text = text + "\n\n========================================"
    return text

# ========== SAMPLE DATA (5 Students, 5 Subjects) ==========
def create_sample_data():
    data = {
        'Student_ID': [1, 1, 1, 1, 1, 
                       2, 2, 2, 2, 2, 
                       3, 3, 3, 3, 3, 
                       4, 4, 4, 4, 4, 
                       5, 5, 5, 5, 5],
        'Subject': ['Math', 'Science', 'English', 'Urdu', 'Computer',
                    'Math', 'Science', 'English', 'Urdu', 'Computer',
                    'Math', 'Science', 'English', 'Urdu', 'Computer',
                    'Math', 'Science', 'English', 'Urdu', 'Computer',
                    'Math', 'Science', 'English', 'Urdu', 'Computer'],
        'Marks': [75, 45, 80, 65, 90,
                  35, 90, 60, 45, 55,
                  85, 70, 55, 80, 95,
                  40, 50, 95, 60, 70,
                  88, 92, 78, 85, 96],
        'Time_Spent': [5, 3, 4, 6, 7,
                       6, 8, 5, 4, 6,
                       4, 6, 7, 5, 8,
                       7, 4, 6, 5, 5,
                       6, 7, 5, 8, 9],
        'Attendance': [90, 70, 85, 75, 95,
                       60, 95, 80, 65, 70,
                       95, 85, 75, 90, 98,
                       65, 80, 90, 70, 75,
                       92, 88, 85, 90, 95]
    }
    return pd.DataFrame(data)

# ========== CORE LOGIC ==========
def get_student_summary(data, student_id):
    student_data = data[data['Student_ID'] == student_id]
    
    summary = {
        'Student_ID': student_id,
        'Subjects': student_data['Subject'].tolist(),
        'Marks': student_data['Marks'].tolist(),
        'Time_Spent': student_data['Time_Spent'].tolist(),
        'Attendance': student_data['Attendance'].tolist()
    }
    
    summary['Avg_Marks'] = np.mean(summary['Marks'])
    summary['Avg_Attendance'] = np.mean(summary['Attendance'])
    summary['Avg_Time'] = np.mean(summary['Time_Spent'])
    
    return summary

def get_recommendations(summary):
    recommendations = {}
    
    subjects = summary['Subjects']
    marks = summary['Marks']
    
    avg_marks = summary['Avg_Marks']
    if avg_marks >= 80:
        overall = "Excellent"
    elif avg_marks >= 65:
        overall = "Good"
    elif avg_marks >= 50:
        overall = "Average"
    else:
        overall = "Needs Improvement"
    
    subject_recs = []
    weak_subjects = []
    strong_subjects = []
    
    for subject, mark in zip(subjects, marks):
        if mark >= 80:
            rec = "Excellent! Help others, explore competitions"
            color = "green"
            strong_subjects.append(subject)
        elif mark >= 65:
            rec = "Good! Try advanced problems"
            color = "blue"
        elif mark >= 50:
            rec = "Practice more, solve sample papers"
            color = "orange"
        else:
            rec = "Focus on basics, daily practice needed"
            color = "red"
            weak_subjects.append(subject)
        
        subject_recs.append({
            'subject': subject,
            'marks': mark,
            'recommendation': rec,
            'color': color
        })
    
    return {
        'overall': overall,
        'avg_marks': avg_marks,
        'subject_recs': subject_recs,
        'weak_subjects': weak_subjects,
        'strong_subjects': strong_subjects,
        'avg_attendance': summary['Avg_Attendance'],
        'avg_time': summary['Avg_Time']
    }

# ========== TRAIN ML MODEL ==========
@st.cache_resource
def train_model():
    np.random.seed(42)
    n_samples = 50
    X = np.random.rand(n_samples, 5) * 100
    y = (X.mean(axis=1) > 50).astype(int)
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)
    
    model = RandomForestClassifier(n_estimators=10, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    accuracy = accuracy_score(y_test, y_pred) * 100
    
    return model, accuracy, X_test, y_test, y_pred

# ========== EXPLANATION MODULE ==========
def generate_explanation(summary, recommendations):
    explanation = """
    How AI Made These Recommendations:
    
    1. Marks Analysis: 
       - Your average marks: """ + str(round(recommendations['avg_marks'], 1)) + """%
       - Overall performance: """ + recommendations['overall'] + """
    
    2. Subject Analysis:
       - Weak subjects (<50%): """ + (', '.join(recommendations['weak_subjects']) if recommendations['weak_subjects'] else 'None') + """
       - Strong subjects (>80%): """ + (', '.join(recommendations['strong_subjects']) if recommendations['strong_subjects'] else 'Keep working!') + """
    
    3. Study Habits:
       - Average Attendance: """ + str(round(recommendations['avg_attendance'], 1)) + """%
       - Average Time Spent: """ + str(round(recommendations['avg_time'], 1)) + """ hours
    
    4. AI Model Used:
       - Random Forest Classifier
       - Features: 5 Subjects (Math, Science, English, Urdu, Computer)
       - Analyzed patterns from all students
    
    5. Recommendation Logic:
       - Based on marks threshold classification
       - Personalized suggestions for each subject
       - Considered time spent and attendance
    """
    return explanation

# ========== VISUALIZATION ==========
def create_visuals(summary, recommendations):
    subjects = summary['Subjects']
    marks = summary['Marks']
    time_spent = summary['Time_Spent']
    attendance = summary['Attendance']
    
    # Time vs Marks Scatter
    time_data = pd.DataFrame({
        'Subject': subjects,
        'Time_Spent': time_spent,
        'Marks': marks,
        'Attendance': attendance
    })
    
    fig_scatter = px.scatter(
        time_data,
        x='Time_Spent',
        y='Marks',
        color='Subject',
        size='Marks',
        title='Time vs Marks Analysis',
        labels={'Time_Spent': 'Time Spent (hours)', 'Marks': 'Marks (%)'},
        color_discrete_sequence=['#1f77b4', '#2ca02c', '#d62728', '#ff7f00', '#9467bd']
    )
    
    fig_scatter.update_layout(
        width=800,
        height=500,
        font_size=14,
        xaxis_title='Time Spent (hours)',
        yaxis_title='Marks (%)',
        legend_title='Subjects'
    )
    
    # Attendance vs Marks
    fig_attendance = px.scatter(
        time_data,
        x='Attendance',
        y='Marks',
        color='Subject',
        size='Marks',
        title='Attendance vs Marks',
        labels={'Attendance': 'Attendance (%)', 'Marks': 'Marks (%)'},
        color_discrete_sequence=['#1f77b4', '#2ca02c', '#d62728', '#ff7f00', '#9467bd']
    )
    
    fig_attendance.update_layout(
        width=800,
        height=500,
        font_size=14,
        xaxis_title='Attendance (%)',
        yaxis_title='Marks (%)',
        legend_title='Subjects'
    )
    
    # Bar Chart
    fig_bar = px.bar(
        x=subjects, 
        y=marks,
        title="Student " + str(summary['Student_ID']) + " - All Subjects Performance",
        labels={'x': 'Subject', 'y': 'Marks (%)'},
        color=marks,
        color_continuous_scale=['red', 'yellow', 'green']
    )
    fig_bar.add_hline(y=50, line_dash="dash", line_color="red", annotation_text="Passing")
    fig_bar.add_hline(y=80, line_dash="dash", line_color="green", annotation_text="Excellent")
    
    # Pie Chart
    fig_pie = px.pie(
        values=marks,
        names=subjects,
        title="Student " + str(summary['Student_ID']) + " - Marks Distribution"
    )
    fig_pie.update_traces(textposition='inside', textinfo='percent+label', texttemplate='%{label}<br>%{percent:.1%}')
    
    # Feature Importance
    model, _, _, _, _ = train_model()
    feature_names = ['Math', 'Science', 'English', 'Urdu', 'Computer']
    importance = model.feature_importances_
    
    fig_importance = px.bar(
        x=feature_names,
        y=importance,
        title="Feature Importance (All 5 Subjects)",
        labels={'x': 'Subject', 'y': 'Importance'},
        color=importance,
        color_continuous_scale='Blues'
    )
    
    return fig_bar, fig_pie, fig_scatter, fig_importance, fig_attendance

# ========== MAIN UI ==========
def main():
    st.title("An AI Tutor for Personalized Student Learning Recommendations")
    st.markdown("Upload student data and get personalized learning recommendations!")
    
    # ===== SIDEBAR =====
    with st.sidebar:
        st.header("Settings")
        
        uploaded_file = st.file_uploader("Upload Student Data (CSV)", type=['csv'])
        
        if uploaded_file is not None:
            data = pd.read_csv(uploaded_file)
            st.success("Loaded " + str(len(data)) + " records")
        else:
            data = create_sample_data()
            st.info("Using sample data (5 students, 5 subjects each)")
        
        student_ids = data['Student_ID'].unique().tolist()
        selected_id = st.selectbox("Select Student ID", student_ids)
        
        run = st.button("Get Recommendations", use_container_width=True)
        
        st.divider()
        
        # ===== DOWNLOAD BUTTON =====
        summary = get_student_summary(data, selected_id)
        recommendations = get_recommendations(summary)
        download_text = get_recommendations_text(recommendations, selected_id)
        
        st.download_button(
            label="Download Recommendations",
            data=download_text,
            file_name="recommendations_student_" + str(selected_id) + ".txt",
            mime="text/plain",
            use_container_width=True
        )
    
    # ===== MAIN CONTENT =====
    if run:
        summary = get_student_summary(data, selected_id)
        recommendations = get_recommendations(summary)
    else:
        summary = get_student_summary(data, selected_id)
        recommendations = get_recommendations(summary)
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Performance Visualization")
        fig_bar, fig_pie, fig_scatter, fig_importance, fig_attendance = create_visuals(summary, recommendations)
        
        st.subheader("Bar Chart")
        st.plotly_chart(fig_bar, use_container_width=True)
        
        st.subheader("Pie Chart")
        st.plotly_chart(fig_pie, use_container_width=True)
        
        st.subheader("Time vs Marks")
        st.plotly_chart(fig_scatter, use_container_width=True)
        
        st.subheader("Attendance vs Marks")
        st.plotly_chart(fig_attendance, use_container_width=True)
    
    with col2:
        st.subheader("Recommendations")
        
        overall = recommendations['overall']
        if "Excellent" in overall:
            st.success("### " + overall)
        elif "Good" in overall:
            st.info("### " + overall)
        elif "Average" in overall:
            st.warning("### " + overall)
        else:
            st.error("### " + overall)
        
        col_a, col_b = st.columns(2)
        with col_a:
            st.metric("Avg Marks", str(round(recommendations['avg_marks'], 1)) + "%")
        with col_b:
            st.metric("Avg Attendance", str(round(recommendations['avg_attendance'], 1)) + "%")
        
        st.markdown("---")
        st.subheader("Subject-wise Recommendations")
        
        for rec in recommendations['subject_recs']:
            color = rec['color']
            if color == "green":
                st.success("**" + rec['subject'] + "** (" + str(rec['marks']) + "%): " + rec['recommendation'])
            elif color == "blue":
                st.info("**" + rec['subject'] + "** (" + str(rec['marks']) + "%): " + rec['recommendation'])
            elif color == "orange":
                st.warning("**" + rec['subject'] + "** (" + str(rec['marks']) + "%): " + rec['recommendation'])
            else:
                st.error("**" + rec['subject'] + "** (" + str(rec['marks']) + "%): " + rec['recommendation'])
    
    st.divider()
    with st.expander("Why these recommendations? (Explanation)", expanded=False):
        explanation = generate_explanation(summary, recommendations)
        st.markdown(explanation)
    
    with st.expander("Model Evaluation (Click to expand)", expanded=False):
        model, accuracy, X_test, y_test, y_pred = train_model()
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Model Accuracy", str(round(accuracy, 1)) + "%")
        with col2:
            st.metric("Test Samples", len(X_test))
        with col3:
            st.metric("Features Used", X_test.shape[1])
        
        report = classification_report(y_test, y_pred, output_dict=True)
        report_df = pd.DataFrame(report).transpose()
        st.dataframe(report_df.style.background_gradient(cmap='Blues'))
        
        st.plotly_chart(fig_importance, use_container_width=True)
    
    st.divider()
    st.caption("An AI Tutor for Personalized Student Learning Recommendations | Built with Streamlit + scikit-learn")

if __name__ == "__main__":
    main()