
# An AI Tutor for Personalized student Learning Recommendations

## Project Goal

A Machine Learning-based web application that analyzes student performance and provides personalized learning recommendations based on marks, attendance, and study time.


## PEAS Description
- **Performance:** Accuracy of personalized learning recommendations
- **Environment:** Web-based learning platform with student data
- **Actuators:** Display recommendations, charts, and feedback
- **Sensors:** Student performance data (CSV input), subject-wise scores


## How to Run

1. Install the required libraries:
   `pip install -r requirements.txt`
2. Run the application:
   `streamlit run app.py`

## Features

* Upload student data (CSV)
* Select a student for analysis
* Personalized learning recommendations
* Subject-wise performance analysis
* Interactive charts and graphs
* AI-powered predictions using Random Forest
* Explainable AI recommendations

## Tech Stack

* Python
* Streamlit
* Scikit-learn
* Pandas
* NumPy
* Plotly

## Project Structure

* `app.py` – Main Streamlit application
* `model.py` – Machine Learning model
* `utils.py` – Helper functions
* `student_data.csv` – Sample dataset
* `requirements.txt` – Required Python libraries

## Machine Learning Model

* Algorithm: Random Forest Classifier
* Task: Student Performance Classification

## Future Improvements

* Add a larger student dataset
* Improve prediction accuracy
* Support real-time data
* Add student progress tracking
* Deploy on Streamlit Cloud

## Created By
*Hassnain Nawaz*
*Saifullah ALI*
*Sohail Abbas*
